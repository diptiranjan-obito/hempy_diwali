import * as THREE from 'three';

/**
 * Generates handmade translucent mulberry paper texture with subtle organic fibres
 * and the approved embossed diamond motif for the 4 lantern panels.
 */
export function createLanternPaperTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 640;
  const ctx = canvas.getContext('2d')!;

  // Warm handmade paper base
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, '#f4ead8');
  grad.addColorStop(0.5, '#fbf4e6');
  grad.addColorStop(1, '#efe2cb');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Subtle organic paper fibres and imperfections
  for (let i = 0; i < 420; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const len = 8 + Math.random() * 28;
    const angle = Math.random() * Math.PI * 2;
    ctx.strokeStyle =
      i % 3 === 0
        ? 'rgba(168, 138, 98, 0.14)'
        : 'rgba(255, 252, 244, 0.35)';
    ctx.lineWidth = 0.7 + Math.random() * 1.1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
    ctx.stroke();
  }

  // Horizontal fold crease (from when the lantern begins folded)
  ctx.strokeStyle = 'rgba(155, 126, 88, 0.22)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(24, canvas.height * 0.5);
  ctx.lineTo(canvas.width - 24, canvas.height * 0.5);
  ctx.stroke();

  // Outer panel border frame
  ctx.strokeStyle = 'rgba(160, 125, 76, 0.38)';
  ctx.lineWidth = 4;
  ctx.strokeRect(26, 26, canvas.width - 52, canvas.height - 52);

  // Approved Diamond Motif on the paper panel
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  const dw = 136;
  const dh = 195;

  // Outer diamond
  ctx.strokeStyle = 'rgba(150, 112, 62, 0.52)';
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.moveTo(cx, cy - dh);
  ctx.lineTo(cx + dw, cy);
  ctx.lineTo(cx, cy + dh);
  ctx.lineTo(cx - dw, cy);
  ctx.closePath();
  ctx.stroke();

  // Inner filigree diamond
  const dw2 = 96;
  const dh2 = 138;
  ctx.strokeStyle = 'rgba(165, 128, 78, 0.36)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx, cy - dh2);
  ctx.lineTo(cx + dw2, cy);
  ctx.lineTo(cx, cy + dh2);
  ctx.lineTo(cx - dw2, cy);
  ctx.closePath();
  ctx.stroke();

  // Center watermark diamond seed
  ctx.fillStyle = 'rgba(180, 140, 82, 0.22)';
  ctx.beginPath();
  ctx.moveTo(cx, cy - 28);
  ctx.lineTo(cx + 20, cy);
  ctx.lineTo(cx, cy + 28);
  ctx.lineTo(cx - 20, cy);
  ctx.closePath();
  ctx.fill();

  // Corner brass eyelet markings
  const corners = [
    [38, 38],
    [canvas.width - 38, 38],
    [38, canvas.height - 38],
    [canvas.width - 38, canvas.height - 38]
  ];
  corners.forEach(([ex, ey]) => {
    ctx.strokeStyle = 'rgba(184, 142, 68, 0.75)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(ex, ey, 9, 0, Math.PI * 2);
    ctx.stroke();
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Generates weathered lime-plaster wall texture & bump map
 */
export function createPlasterTexture(): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#3b4254';
  ctx.fillRect(0, 0, 512, 512);

  // Weathering patches
  for (let i = 0; i < 180; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 16 + Math.random() * 64;
    const g = ctx.createRadialGradient(x, y, 2, x, y, r);
    const tone = i % 2 === 0 ? 'rgba(72, 78, 96, 0.18)' : 'rgba(32, 36, 48, 0.22)';
    g.addColorStop(0, tone);
    g.addColorStop(1, 'transparent');
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  const map = new THREE.CanvasTexture(canvas);
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;

  return { map, bumpMap: map };
}

/**
 * Generates uneven cobblestone texture and bump map for the Sleeping Street & Courtyard
 */
export function createCobblestoneTexture(): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep mortar background
  ctx.fillStyle = '#141926';
  ctx.fillRect(0, 0, 512, 512);

  const rows = 10;
  const cols = 8;
  const cellW = 512 / cols;
  const cellH = 512 / rows;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const offsetX = (r % 2) * (cellW * 0.45);
      const cx = ((c * cellW + offsetX) % 512) + (Math.random() - 0.5) * 6;
      const cy = r * cellH + cellH * 0.5 + (Math.random() - 0.5) * 5;
      const rx = cellW * (0.38 + Math.random() * 0.08);
      const ry = cellH * (0.36 + Math.random() * 0.09);

      const grad = ctx.createRadialGradient(cx - 4, cy - 4, 2, cx, cy, Math.max(rx, ry));
      const shade = 52 + Math.floor(Math.random() * 28);
      grad.addColorStop(0, `rgb(${shade + 18}, ${shade + 22}, ${shade + 35})`);
      grad.addColorStop(0.75, `rgb(${shade}, ${shade + 4}, ${shade + 14})`);
      grad.addColorStop(1, '#181e2c');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx, ry, (Math.random() - 0.5) * 0.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const map = new THREE.CanvasTexture(canvas);
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(3, 4);

  return { map, bumpMap: map };
}
