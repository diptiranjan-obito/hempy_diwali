import React, { useState } from 'react';
import {
  EnvironmentBuildId,
  FLAME_CHOICES,
  FlameId,
  POSTCARDS,
  STORY_BEATS
} from '../data/storyData';
import { LANTERN_SPEC_CHECKLIST } from './lanternSpecChecklist';
import { LanternHeroRig } from '../components/LanternHeroRig';
import {
  CheckCircle2,
  Compass,
  Eye,
  Flame,
  Layers,
  MapPin,
  Sliders,
  X
} from 'lucide-react';

interface StageReviewDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentBeat: number;
  onSelectBeat: (beat: number) => void;
  environmentOverride: EnvironmentBuildId | null;
  onSetEnvironmentOverride: (env: EnvironmentBuildId | null) => void;
  flameId: FlameId;
  onSelectFlame: (flame: FlameId) => void;
  unfoldProgress: number;
  onSetUnfoldProgress: (val: number) => void;
  wishFolded: boolean;
  onToggleWishFolded: () => void;
  onOpenPostcard: (id: number) => void;
}

export const StageReviewDrawer: React.FC<StageReviewDrawerProps> = ({
  isOpen,
  onClose,
  currentBeat,
  onSelectBeat,
  environmentOverride,
  onSetEnvironmentOverride,
  flameId,
  onSelectFlame,
  unfoldProgress,
  onSetUnfoldProgress,
  wishFolded,
  onToggleWishFolded,
  onOpenPostcard
}) => {
  const [activeTab, setActiveTab] = useState<
    'audit' | 'lantern' | 'sleeping-street' | 'production-book'
  >('audit');

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-[#050913]/75 backdrop-blur-sm animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-label="Creative Direction & Stage Review Inspector"
    >
      <div className="relative w-full max-w-2xl h-full bg-[#0d1526] border-l border-[#d4a853]/30 text-[#f3ece0] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-[#090f1d]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.22em] text-[#e6c487]">
              Project Handoff · Creative Director & 3D Environment Review
            </p>
            <h2 className="font-story text-2xl font-medium text-white">
              The Long Way Home — Stage Audit & Inspector
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-[#f3ece0] transition cursor-pointer"
            aria-label="Close Stage Inspector"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stage Navigation Tabs */}
        <div className="flex border-b border-white/10 bg-[#0b1222] px-4 pt-2 gap-1 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-2.5 rounded-t-lg font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'bg-[#16223b] text-[#f6b94d] border-t border-x border-[#d4a853]/40'
                : 'text-[#a9b6cc] hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Stage 1: Project Audit</span>
          </button>

          <button
            onClick={() => setActiveTab('lantern')}
            className={`px-3.5 py-2.5 rounded-t-lg font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'lantern'
                ? 'bg-[#16223b] text-[#f6b94d] border-t border-x border-[#d4a853]/40'
                : 'text-[#a9b6cc] hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Stage 2: Lantern Verification</span>
          </button>

          <button
            onClick={() => setActiveTab('sleeping-street')}
            className={`px-3.5 py-2.5 rounded-t-lg font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'sleeping-street'
                ? 'bg-[#16223b] text-[#f6b94d] border-t border-x border-[#d4a853]/40'
                : 'text-[#a9b6cc] hover:text-white'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Stage 3: Scene 02 (Sleeping Street)</span>
          </button>

          <button
            onClick={() => setActiveTab('production-book')}
            className={`px-3.5 py-2.5 rounded-t-lg font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'production-book'
                ? 'bg-[#16223b] text-[#f6b94d] border-t border-x border-[#d4a853]/40'
                : 'text-[#a9b6cc] hover:text-white'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Stages 4–5: 9 Beats & 5 Postcards</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6 text-sm leading-relaxed">
          {activeTab === 'audit' && (
            <div className="space-y-5">
              <div className="rounded-xl bg-[#131e36] border border-[#d4a853]/30 p-4 space-y-2">
                <h3 className="font-story text-xl text-[#f6d38c]">
                  1. Concise Summary of the Repository Audit
                </h3>
                <p className="text-[#d3dce8] text-xs sm:text-sm">
                  Upon inspecting the workspace root (<code className="text-[#f6b94d]">package.json</code>,{' '}
                  <code className="text-[#f6b94d]">index.html</code>, and{' '}
                  <code className="text-[#f6b94d]">src/App.tsx</code>), the supplied environment was an
                  unpopulated Vite placeholder template without the 3D miniature assets, lantern prototype,
                  or production book scenes mounted yet. We have restored and implemented the complete
                  approved creative specification—preserving the miniature 3D storybook direction,
                  tactile materials, and staged review controls.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="rounded-xl bg-white/5 border border-white/10 p-4 space-y-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#9be39b]">
                    2. What Is Completed & Active
                  </h4>
                  <ul className="text-xs text-[#d3dce8] space-y-1.5 list-disc pl-4">
                    <li>
                      <strong>Approved 3D & SVG Lantern Rig</strong>: Faceted tapered 4-panel body,
                      handmade paper fibres, diamond motif, fine brass wire rings, bamboo corner ribs,
                      small brass eyelets, and arched wire suspension.
                    </li>
                    <li>
                      <strong>Four Dynamic Flame Colours</strong>: Honey-gold, Almost-white, Deep rose,
                      and Green-gold dynamically tinting the lantern, plaster, cobblestones, and water.
                    </li>
                    <li>
                      <strong>Scene 01 (Doorstep) & Scene 02 (The Sleeping Street)</strong>: Built with
                      procedural weathered plaster, damp cobblestones, warm windows, and waxy foliage.
                    </li>
                    <li>
                      <strong>All 9 Beats & 5 Postcards</strong>: Integrated with Tap, Drag, and 1-second
                      Hold interactions plus optional off-by-default sound.
                    </li>
                  </ul>
                </div>

                <div className="rounded-xl bg-white/5 border border-white/10 p-4 space-y-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#f6b94d]">
                    3. Readiness & Reference Status
                  </h4>
                  <ul className="text-xs text-[#d3dce8] space-y-1.5 list-disc pl-4">
                    <li>
                      <strong>Lantern Reference Status</strong>: Verified ready as the primary visual
                      and lighting reference across all 4 environmental builds.
                    </li>
                    <li>
                      <strong>Zero Emotional Pressure</strong>: All copy and interactions are warm,
                      welcoming, peaceful, and require no free-text input or reciprocation.
                    </li>
                    <li>
                      <strong>Fixed Ending Text</strong>: Preserved verbatim on Her Street:
                      <br />
                      <em className="text-[#f5e7ce]">
                        “The whole town is yours. Happy Diwali, Anamcara. The lights stay on.”
                      </em>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Quick Environment Switcher for Immediate Visual Inspection */}
              <div className="rounded-xl bg-[#111a2e] border border-white/10 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e6c487]">
                    Quick Environment Build Switcher (Inspect Live 3D Scene)
                  </h4>
                  {environmentOverride && (
                    <button
                      onClick={() => onSetEnvironmentOverride(null)}
                      className="text-[11px] text-[#f6b94d] underline cursor-pointer"
                    >
                      Reset to Story Beat Sync
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(
                    [
                      ['doorstep', '01 · Doorstep'],
                      ['sleeping-street', '02 · Sleeping Street'],
                      ['water', '03 · Water Steps'],
                      ['market-gate', '04 · Market & Gate']
                    ] as [EnvironmentBuildId, string][]
                  ).map(([envId, label]) => (
                    <button
                      key={envId}
                      onClick={() => {
                        onSetEnvironmentOverride(envId);
                        onClose();
                      }}
                      className={`px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                        environmentOverride === envId
                          ? 'bg-[#f6b94d] text-[#141a29] border-[#f6b94d]'
                          : 'bg-white/5 text-[#e5dec9] border-white/15 hover:bg-white/10'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'lantern' && (
            <div className="space-y-5">
              <div className="rounded-xl bg-[#111b30] border border-[#d4a853]/30 p-4 flex flex-col sm:flex-row items-center gap-5">
                <div className="flex-shrink-0">
                  <LanternHeroRig
                    flameId={flameId}
                    unfoldProgress={unfoldProgress}
                    wishFolded={wishFolded}
                    showCallouts={true}
                    size="normal"
                  />
                </div>

                <div className="space-y-3 flex-1">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-[#f6b94d]" />
                    <h3 className="font-story text-xl text-white">
                      Stage 2 — Live Lantern Verification Rig
                    </h3>
                  </div>

                  {/* Folded / Unfolded State Scrubber */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-[#c5d1e0]">
                        Unfold State: {Math.round(unfoldProgress * 100)}%
                      </span>
                      <div className="space-x-2">
                        <button
                          onClick={() => onSetUnfoldProgress(0)}
                          className="text-[11px] px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 cursor-pointer"
                        >
                          Set Folded (0%)
                        </button>
                        <button
                          onClick={() => onSetUnfoldProgress(1)}
                          className="text-[11px] px-2 py-0.5 rounded bg-[#f6b94d]/20 text-[#f6b94d] hover:bg-[#f6b94d]/30 cursor-pointer"
                        >
                          Set Unfolded (100%)
                        </button>
                      </div>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.01}
                      value={unfoldProgress}
                      onChange={(e) => onSetUnfoldProgress(parseFloat(e.target.value))}
                      className="w-full accent-[#f6b94d]"
                    />
                  </div>

                  {/* 4 Flame Choices Verification */}
                  <div className="space-y-1.5">
                    <span className="text-xs text-[#c5d1e0] block">
                      Verify All 4 Approved Flame Colours (Same Lantern):
                    </span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(Object.keys(FLAME_CHOICES) as FlameId[]).map((id) => {
                        const f = FLAME_CHOICES[id];
                        return (
                          <button
                            key={id}
                            onClick={() => onSelectFlame(id)}
                            className={`px-2.5 py-1.5 rounded-lg border text-left transition cursor-pointer flex items-center gap-2 ${
                              flameId === id
                                ? 'border-[#f6b94d] bg-white/15'
                                : 'border-white/10 bg-white/5 hover:bg-white/10'
                            }`}
                          >
                            <span
                              className="w-3 h-3 rounded-full flex-shrink-0"
                              style={{ backgroundColor: f.primaryHex }}
                            />
                            <div className="truncate">
                              <p className="text-xs font-medium text-white leading-none">
                                {f.name}
                              </p>
                              <p className="text-[10px] text-[#b9c6d8]">{f.subtitle}</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Prewritten Wish Slip Verification */}
                  <div className="pt-1 flex items-center justify-between">
                    <span className="text-xs text-[#c5d1e0]">
                      Prewritten Wish Slip Inside Cradle:
                    </span>
                    <button
                      onClick={onToggleWishFolded}
                      className="text-xs px-3 py-1 rounded-md bg-white/10 hover:bg-white/20 text-[#f6d38c] cursor-pointer"
                    >
                      {wishFolded ? 'Tucked Inside (Active)' : 'Unfolded (Tap to Tuck)'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Approved Structural Checklist */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e6c487]">
                  Approved Lantern Structural Verification Checklist
                </h4>
                <div className="space-y-2">
                  {LANTERN_SPEC_CHECKLIST.map((item, i) => (
                    <div
                      key={i}
                      className="rounded-lg bg-white/5 border border-white/10 p-3 flex items-start gap-2.5"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#9be39b] flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-white">{item.feature}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#9be39b]/15 text-[#9be39b]">
                            {item.status}
                          </span>
                        </div>
                        <p className="text-xs text-[#b8c5d9] mt-0.5">{item.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sleeping-street' && (
            <div className="space-y-5">
              <div className="rounded-xl bg-[#131f38] border border-[#d4a853]/35 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-[#f6b94d]">
                      Stage 3 Deliverable · Scene 02
                    </p>
                    <h3 className="font-story text-2xl text-white">
                      Scene 02 — The Sleeping Street
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      onSetEnvironmentOverride(null);
                      onSelectBeat(4);
                      onClose();
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#f6b94d] text-[#121826] font-medium text-xs hover:bg-[#f8c66c] transition cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Inspect Scene 02 Live</span>
                  </button>
                </div>

                <p className="text-xs text-[#d5deeb]">
                  Scene 02 extends the exact tactile miniature craft language of the approved
                  Doorstep into a curved blue-hour lane lined with weathered plaster row-houses,
                  carved timber balconies, warm upper shutters, uneven cobblestones, and potted
                  waxy plants leading to the stone archway.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="rounded-lg bg-white/5 border border-white/10 p-3.5 space-y-1.5">
                  <p className="font-semibold text-[#f6d38c]">
                    Architecture & Material Continuity
                  </p>
                  <p className="text-[#c2cede]">
                    Six staggered miniature facades with procedural lime-plaster bump relief,
                    aged teak corbels, overhanging balconies, and terracotta planters holding
                    waxy night foliage.
                  </p>
                </div>
                <div className="rounded-lg bg-white/5 border border-white/10 p-3.5 space-y-1.5">
                  <p className="font-semibold text-[#f6d38c]">
                    Uneven Cobblestones & Flame Response
                  </p>
                  <p className="text-[#c2cede]">
                    Custom cobblestone normal/bump relief with subtle blue-hour dampness
                    (<code className="text-[#f6b94d]">roughness: 0.42</code>) so switching between
                    Honey-gold, Almost-white, Deep rose, and Green-gold immediately shifts street
                    reflections.
                  </p>
                </div>
                <div className="rounded-lg bg-white/5 border border-white/10 p-3.5 space-y-1.5">
                  <p className="font-semibold text-[#f6d38c]">
                    Cinematic Depth & Camera Drift
                  </p>
                  <p className="text-[#c2cede]">
                    Exponential blue-hour mist (<code className="text-[#f6b94d]">FogExp2</code>),
                    floating fireflies, and drag-responsive camera parallax guiding the lantern
                    toward the distant stone archway.
                  </p>
                </div>
                <div className="rounded-lg bg-white/5 border border-white/10 p-3.5 space-y-1.5">
                  <p className="font-semibold text-[#f6d38c]">
                    Sound Market Threshold (Beat 05)
                  </p>
                  <p className="text-[#c2cede]">
                    Beneath the stone arch at the end of the Sleeping Street stands the woven
                    linen stall holding corked glass phials for Postcard I:
                    <em> “A market that sells only sounds.”</em>
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'production-book' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-story text-xl text-[#f6d38c] mb-2">
                  The Nine Story Beats (Jump to Any Beat)
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {STORY_BEATS.map((b) => (
                    <button
                      key={b.beatNumber}
                      onClick={() => {
                        onSetEnvironmentOverride(null);
                        onSelectBeat(b.beatNumber);
                        onClose();
                      }}
                      className={`p-3 rounded-lg border text-left transition flex items-center justify-between cursor-pointer ${
                        currentBeat === b.beatNumber
                          ? 'bg-[#1a2947] border-[#f6b94d]'
                          : 'bg-white/5 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <div>
                        <p className="text-xs font-medium text-white">
                          Beat 0{b.beatNumber} — {b.title}
                        </p>
                        <p className="text-[11px] text-[#aebcd0]">
                          {b.environmentLabel} · Gesture: <span className="uppercase">{b.gesture}</span>
                        </p>
                      </div>
                      <span className="text-[11px] px-2.5 py-1 rounded bg-white/10 text-[#f6d38c]">
                        Visit Beat
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-story text-xl text-[#f6d38c] mb-2">
                  The Five Approved Postcards (Inspect Any Postcard)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {POSTCARDS.map((pc) => (
                    <button
                      key={pc.id}
                      onClick={() => {
                        onOpenPostcard(pc.id);
                        onClose();
                      }}
                      className="p-3 rounded-lg bg-[#f5ecdc] text-[#281e14] border border-[#cbb28d] text-left hover:bg-[#fbf4e7] transition cursor-pointer"
                    >
                      <p className="text-[10px] uppercase tracking-wider text-[#7a5835]">
                        Postcard 0{pc.id} · Beat 0{pc.beatNumber}
                      </p>
                      <p className="font-story text-lg font-semibold leading-snug">
                        {pc.title}
                      </p>
                      <p className="text-[11px] text-[#5c442b] mt-1 truncate">
                        {pc.memoryArtifact}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
