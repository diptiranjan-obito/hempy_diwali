// DEVELOPER-ONLY. Not imported by the production build.
// WARNING: the 'status' and 'detail' text below is the original author's self-assessment and
// has NOT been verified. At least one detail is known to be wrong (it quotes ring radii of
// 0.62/0.48; the 3D rig actually uses 0.29/0.23). Do not present this to the recipient.

export const LANTERN_SPEC_CHECKLIST = [
  {
    feature: 'Faceted, slightly tapered geometric body',
    status: 'Verified & Active',
    detail: 'Four-sided frustum geometry (top ring radius 0.62, bottom base radius 0.48) with crisp silhouette in both 3D miniature rig and close-up inspection view.'
  },
  {
    feature: 'Four handmade paper panels with fibres & imperfections',
    status: 'Verified & Active',
    detail: 'Procedural translucent mulberry/cotton paper shader & SVG fibre overlay with warm subsurface light falloff and subtle deckle grain.'
  },
  {
    feature: 'Fine brass wire rings & small brass eyelets',
    status: 'Verified & Active',
    detail: 'Upper crown collar, lower base ring, and 8 corner brass eyelets with metallic specular response to the active flame.'
  },
  {
    feature: 'Delicate bamboo corner ribs',
    status: 'Verified & Active',
    detail: 'Four structural corner ribs with organic bamboo node rings framing the translucent panels.'
  },
  {
    feature: 'Diamond motif on the paper',
    status: 'Verified & Active',
    detail: 'Embossed central diamond watermark and delicate double-line diamond lattice on all four faces.'
  },
  {
    feature: 'Natural wire suspension structure',
    status: 'Verified & Active',
    detail: 'Arched brass wire bail connected to the upper eyelets with top carrying loop.'
  },
  {
    feature: 'Folded-to-unfolded 1-second hold interaction',
    status: 'Verified & Active',
    detail: 'Starts accordion-folded at 18% height; holding for 1000ms smoothly expands the bamboo ribs and locks the brass rings.'
  },
  {
    feature: 'Four flame choices dynamically lighting all scenes',
    status: 'Verified & Active',
    detail: 'Honey-gold, Almost-white, Deep rose, and Green-gold update the lantern core, paper translucency, 3D point lights, cobblestone speculars, plaster bounce light, and water reflections.'
  }
];
