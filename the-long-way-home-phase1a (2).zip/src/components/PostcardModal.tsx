import React, { useState } from 'react';
import { FlameConfig, PostcardData } from '../data/storyData';
import { RotateCw, Sparkles, X, BookOpen } from 'lucide-react';
import { soundEngine } from '../utils/soundEngine';

interface PostcardModalProps {
  postcard: PostcardData;
  flame: FlameConfig;
  onClose: () => void;
  onContinueJourney?: () => void;
  isFinalPostcard?: boolean;
}

export const PostcardModal: React.FC<PostcardModalProps> = ({
  postcard,
  flame,
  onClose,
  onContinueJourney,
  isFinalPostcard = false
}) => {
  const [flipped, setFlipped] = useState(false);

  const handleFlip = () => {
    soundEngine.playPaperFold();
    setFlipped((prev) => !prev);
  };

  // Custom miniature architectural sketch SVG per postcard
  const renderMiniatureSketch = (id: number) => {
    switch (id) {
      case 1: // A market that sells only sounds
        return (
          <svg viewBox="0 0 360 190" className="w-full h-44 rounded border border-[#c9b493]/60">
            <rect width="360" height="190" fill="#182238" />
            {/* Lantern glow in sketch */}
            <circle cx="180" cy="105" r="78" fill={flame.primaryHex} opacity="0.22" />
            {/* Stone Archway */}
            <path
              d="M 40 185 L 40 55 Q 180 -10 320 55 L 320 185"
              fill="none"
              stroke="#d9c6a5"
              strokeWidth="2.2"
            />
            {/* Woven Awning */}
            <path
              d="M 65 78 L 295 78 L 280 104 L 80 104 Z"
              fill="#7c4738"
              opacity="0.78"
              stroke="#e5cfa9"
              strokeWidth="1.2"
            />
            {/* Stoneware Sound Jars & Phials */}
            {[105, 142, 180, 218, 255].map((jx, idx) => (
              <g key={idx}>
                <rect
                  x={jx - 11}
                  y="122"
                  width="22"
                  height="32"
                  rx="5"
                  fill={flame.primaryHex}
                  fillOpacity="0.32"
                  stroke="#f2e4cb"
                  strokeWidth="1.4"
                />
                <rect x={jx - 6} y="116" width="12" height="6" fill="#c99b49" />
                {/* Sound wave rings */}
                <circle
                  cx={jx}
                  cy="138"
                  r={4 + (idx % 2) * 3}
                  fill="none"
                  stroke={flame.coreHex}
                  strokeWidth="0.9"
                  strokeDasharray="2 2"
                />
              </g>
            ))}
            {/* Stall Table */}
            <line x1="70" y1="155" x2="290" y2="155" stroke="#d9c6a5" strokeWidth="2" />
          </svg>
        );
      case 2: // A sea that keeps everything
        return (
          <svg viewBox="0 0 360 190" className="w-full h-44 rounded border border-[#c9b493]/60">
            <rect width="360" height="190" fill="#101b30" />
            <ellipse cx="195" cy="135" rx="115" ry="38" fill={flame.primaryHex} opacity="0.24" />
            {/* Stone Ghat Steps */}
            <path
              d="M 20 80 L 145 80 L 145 98 L 175 98 L 175 116 L 205 116"
              fill="none"
              stroke="#d8c6a8"
              strokeWidth="2"
            />
            {/* Ripples & Paper Boats */}
            <path
              d="M 110 142 L 130 142 L 120 128 Z"
              fill="#fbf3e4"
              stroke={flame.primaryHex}
              strokeWidth="1.2"
            />
            <path
              d="M 225 152 L 248 152 L 236 136 Z"
              fill="#fbf3e4"
              stroke={flame.primaryHex}
              strokeWidth="1.2"
            />
            {[135, 152, 168].map((ry, i) => (
              <line
                key={i}
                x1={60 + i * 18}
                y1={ry}
                x2={310 - i * 15}
                y2={ry}
                stroke={flame.waterReflectionHex}
                strokeWidth="1.1"
                strokeDasharray="8 5"
                opacity="0.7"
              />
            ))}
          </svg>
        );
      case 3: // A shop that only stocks yesterday
        return (
          <svg viewBox="0 0 360 190" className="w-full h-44 rounded border border-[#c9b493]/60">
            <rect width="360" height="190" fill="#192033" />
            <rect
              x="78"
              y="32"
              width="204"
              height="130"
              rx="4"
              fill={flame.primaryHex}
              fillOpacity="0.22"
              stroke="#dec9a6"
              strokeWidth="2"
            />
            {/* Multipaned Bow Window Grid */}
            {[128, 180, 232].map((wx) => (
              <line key={wx} x1={wx} y1="32" x2={wx} y2="162" stroke="#dec9a6" strokeWidth="1.4" />
            ))}
            {[75, 118].map((wy) => (
              <line key={wy} x1="78" y1={wy} x2="282" y2={wy} stroke="#dec9a6" strokeWidth="1.4" />
            ))}
            {/* Bottled hours & teacup silhouettes */}
            <circle cx="154" cy="98" r="11" fill={flame.coreHex} opacity="0.75" />
            <circle cx="206" cy="98" r="11" fill={flame.primaryHex} opacity="0.75" />
            <rect x="142" y="134" width="24" height="18" rx="3" fill="#e6d2b2" opacity="0.8" />
          </svg>
        );
      case 4: // A library of books nobody wrote
        return (
          <svg viewBox="0 0 360 190" className="w-full h-44 rounded border border-[#c9b493]/60">
            <rect width="360" height="190" fill="#161f33" />
            <circle cx="180" cy="95" r="76" fill={flame.primaryHex} opacity="0.2" />
            {/* Arched Timber Bookcases */}
            {[65, 145, 225].map((bx, i) => (
              <g key={i}>
                <path
                  d={`M ${bx} 165 L ${bx} 58 Q ${bx + 35} 30 ${bx + 70} 58 L ${bx + 70} 165`}
                  fill="none"
                  stroke="#dfc9a6"
                  strokeWidth="1.8"
                />
                {[85, 115, 145].map((sy) => (
                  <line
                    key={sy}
                    x1={bx + 6}
                    y1={sy}
                    x2={bx + 64}
                    y2={sy}
                    stroke="#c99b49"
                    strokeWidth="1.3"
                  />
                ))}
              </g>
            ))}
          </svg>
        );
      default: // Postcard 5: Her street
        return (
          <svg viewBox="0 0 360 190" className="w-full h-44 rounded border border-[#c9b493]/60">
            <rect width="360" height="190" fill="#121c31" />
            {/* Five glowing lights across the miniature town */}
            {[62, 118, 178, 238, 296].map((lx, idx) => (
              <g key={idx}>
                <circle
                  cx={lx}
                  cy={88 - (idx % 2) * 14}
                  r={idx === 4 ? 28 : 16}
                  fill={flame.primaryHex}
                  opacity={idx === 4 ? 0.42 : 0.25}
                />
                <circle
                  cx={lx}
                  cy={88 - (idx % 2) * 14}
                  r={idx === 4 ? 6 : 3.5}
                  fill={flame.coreHex}
                />
              </g>
            ))}
            {/* Curving cobblestone lane homeward */}
            <path
              d="M 30 178 Q 150 135 295 112"
              fill="none"
              stroke={flame.primaryHex}
              strokeWidth="2.2"
              strokeDasharray="5 4"
            />
            {/* Window ledge & resting lantern */}
            <rect x="255" y="112" width="68" height="10" fill="#d9c5a3" />
            <rect
              x="280"
              y="84"
              width="20"
              height="28"
              rx="2"
              fill={flame.coreHex}
              stroke="#c99b49"
              strokeWidth="1.5"
            />
          </svg>
        );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex overflow-y-auto px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-[max(1rem,env(safe-area-inset-bottom))] bg-[#060a14]/80 backdrop-blur-md animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-label={`Postcard ${postcard.id}: ${postcard.title}`}
    >
      <div className="relative w-full max-w-xl m-auto">
        {/* Top bar above physical postcard */}
        <div className="flex items-center justify-between mb-3 px-1 text-xs text-[#dfd3be]/90">
          <span className="inline-flex items-center gap-1.5 uppercase tracking-widest text-[11px] text-[#e6c487]">
            <BookOpen className="w-3.5 h-3.5" />
            {postcard.locationLabel}
          </span>
          <button
            onClick={onClose}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-[#f5efe4] transition"
            aria-label="Close postcard view"
          >
            <X className="w-3.5 h-3.5" />
            <span>Close</span>
          </button>
        </div>

        {/* Physical Handmade Paper Postcard Surface */}
        <div
          className="paper-texture relative rounded-xl p-5 sm:p-7 text-[#2b2118] shadow-[0_24px_60px_rgba(0,0,0,0.75)] border border-[#d8c3a2] transition-all duration-500"
          style={{
            boxShadow: `0 25px 60px rgba(0,0,0,0.75), 0 0 42px ${flame.primaryHex}28`
          }}
        >
          {/* Brass Eyelet in top-left corner of postcard */}
          <div
            className="w-3.5 h-3.5 rounded-full border-2 border-[#b5893d] bg-[#241b12] absolute top-4 left-4"
            title="Small brass eyelet"
          />

          {!flipped ? (
            /* FRONT OF POSTCARD: Traveller's Sketch & Memory Artifact */
            <div className="space-y-4 pt-2">
              <div className="flex items-baseline justify-between border-b border-[#cab391] pb-2.5 pl-5">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.18em] text-[#7a5c3c]">
                    Traveller’s Sketchbook Study · No. 0{postcard.id}
                  </p>
                  <h3 className="font-story text-2xl sm:text-3xl font-medium text-[#231910]">
                    {postcard.title}
                  </h3>
                </div>
                <span
                  className="text-[10px] font-medium px-2.5 py-1 rounded-full border border-[#b5893d]/50"
                  style={{ backgroundColor: `${flame.primaryHex}25` }}
                >
                  {flame.name} light
                </span>
              </div>

              {/* Miniature Architectural Sketch */}
              {renderMiniatureSketch(postcard.id)}

              <p className="font-narrative italic text-xs sm:text-sm text-[#5c452d]">
                {postcard.sketchCaption}
              </p>

              <blockquote className="font-story text-lg sm:text-xl text-[#2d2013] border-l-2 border-[#b5893d] pl-3.5 py-0.5">
                “{postcard.frontQuote}”
              </blockquote>

              <div className="rounded-lg bg-[#eadbc3]/75 border border-[#cbb28d] p-3 text-xs text-[#4a3723]">
                <span className="font-semibold uppercase tracking-wider text-[10px] text-[#7a5835] block mb-0.5">
                  Collected Memory Kept Here:
                </span>
                {postcard.memoryArtifact}
              </div>
            </div>
          ) : (
            /* BACK OF POSTCARD: Personal Handwritten Note for Anamcara */
            <div className="space-y-4 pt-2 min-h-[330px] flex flex-col justify-between">
              <div className="flex items-start justify-between border-b border-[#cab391] pb-3 pl-5">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.2em] text-[#7a5c3c]">
                    POSTCARD · THE LONG WAY HOME
                  </p>
                  <p className="font-story text-2xl font-medium text-[#231910] mt-0.5">
                    {postcard.backGreeting}
                  </p>
                </div>

                {/* Postage Stamp Box */}
                <div className="border border-dashed border-[#8c6b43] bg-[#efe2cc] px-2.5 py-1.5 text-right rounded-sm max-w-[145px]">
                  <p className="text-[9px] uppercase tracking-widest text-[#6b4e2e] font-medium leading-tight">
                    {postcard.stampLabel}
                  </p>
                </div>
              </div>

              <div className="space-y-3 font-narrative text-sm sm:text-base leading-relaxed text-[#2e2217] py-1">
                {postcard.backBody.map((para, index) => (
                  <p key={index}>{para}</p>
                ))}
              </div>

              <div className="pt-3 border-t border-[#cab391]/70 flex items-center justify-between text-xs text-[#694f34]">
                <span className="font-story italic text-base text-[#3b2a1a]">
                  — {postcard.backSignoff}
                </span>
                <span className="text-[11px] uppercase tracking-wider">
                  Recipient: Anamcara
                </span>
              </div>
            </div>
          )}

          {/* Bottom Postcard Actions */}
          <div className="mt-5 pt-3 border-t border-[#cab391] flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={handleFlip}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#2b2015] text-[#f7efe2] hover:bg-[#3d2e1f] text-xs sm:text-sm font-medium transition cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>{flipped ? 'View Front Sketch' : 'Turn Postcard Over (Read Note)'}</span>
            </button>

            {onContinueJourney && (
              <button
                onClick={() => {
                  onClose();
                  onContinueJourney();
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[#7a5835] text-[#2b2015] hover:bg-[#e5d2b5] text-xs sm:text-sm font-medium transition cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#9c6d2e]" />
                <span>{isFinalPostcard ? 'Rest on Her Street' : 'Continue Along the Lane'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
