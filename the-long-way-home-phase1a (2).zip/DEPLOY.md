# Deploying The Long Way Home to GitHub Pages (from an Android phone)

No terminal needed. **I have not run any of these steps on GitHub.** The first run is the test. Items marked "tested locally" were run as plain shell scripts on my side, not on GitHub.

## Key fact
GitHub does NOT unpack an uploaded ZIP. Uploading the ZIP only adds one file to the repository. The workflow below is what unpacks it, installs and builds.

## Route A: upload the ZIP (recommended on a phone)
1. Create a repository on github.com (use "Desktop site" in your browser menu if buttons are missing). Tick "Add a README". Keep the default branch name `main` (the workflow only triggers on `main`).
2. **Settings, then Pages. Under "Build and deployment", set Source to "GitHub Actions".** Do this before the next steps.
3. **Add file, then Create new file.** In the name box type exactly `.github/workflows/deploy.yml`. Paste the whole contents of `deploy-from-zip.yml` (supplied separately in the chat, also inside the ZIP at `docs/deploy-from-zip.yml`). Press **Commit changes**.
   - A run starts. It is expected to finish green but say "No .zip in the repository root yet" (a notice, not an error).
4. **Add file, then Upload files.** Choose `the-long-way-home-phase1a.zip` and press **Commit changes**. This push triggers the real run. Keep exactly one `.zip` in the repository root.
5. Open the **Actions** tab. Steps in the run: check, then Unpack, Install (`npm ci`), Build, Verify build output, upload, deploy. Takes a few minutes. Green = published.
6. Your link: `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`. Pages can take a minute after a green run.

To update later: delete the old ZIP in the repository, upload the new one. The new push triggers a new run.

## Route B: normal repository (only if you can upload folders, e.g. from a laptop)
Put the unzipped project in the repository root (`package.json`, `package-lock.json`, `src/`, `.github/workflows/deploy.yml` all at the top level). Do step 2. The source-mode workflow runs on the next push.

Never use both routes in one repository. If both are somehow present, each workflow checks the layout first (package.json in the root means source mode; one ZIP and no package.json means ZIP mode), so at most one builds, and both share one concurrency group so deployments cannot overlap.

## If something goes wrong
- **Red cross:** open the run, open the failed step, send me the red lines or a screenshot.
- **"Get Pages site failed" / "Not Found":** step 2 was missed. Do it, then Actions, open the failed run, Re-run all jobs.
- **"Found 2 .zip files":** delete the older ZIP.
- **"Verify build output" fails:** it protects you from publishing a broken or developer-version build. Send me the message.
- **Page opens but is blank/black:** that is a Phase 1B finding. Tell me the device and browser.

## Privacy
The Pages link works for anyone who has it, even if the repository is private (private-repo Pages needs a paid plan). `index.html` has a `noindex` tag, which only asks search engines not to list it.
