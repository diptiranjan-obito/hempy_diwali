# Layout audit and fix: text overlapping the 3D scene

## What was and was not verified
VERIFIED (rendered in headless Chromium, measured and screenshotted): the real `App.tsx` markup and compiled Tailwind CSS, at 10 viewport sizes x 9 beats, using a **placeholder** in place of the 3D canvas (a gradient with a dashed "subject zone" circle at the camera look-at point, about a third of the stage, centred).
NOT VERIFIED: the real Three.js scenes (Three.js and the dependencies are not available in my environment), real fonts (Google Fonts are not reachable, so fallback serif/sans fonts were used; text heights on your phone may differ by a line or two), iOS Safari, real address-bar behaviour, real notches/safe-area insets, touch gestures. The camera framing was not changed, so whether each real subject sits at the stage centre is an assumption taken from the camera targets (all at x=0; y between 0.9 and 1.3 world units).
Please treat the screenshots as layout proofs, not as visual sign-off on the scenes.

## Exact cause (all beats, all sizes)
1. The WebGL canvas filled the whole viewport (`absolute inset-0`) and the story panel (title, note, 2 paragraphs, controls, stepper; 0.45 to 0.8 of the screen height on phones) was layered on top of it. The camera frames its subject at the centre of the full viewport, which is exactly where the panel sits on a phone: it covered 21-100% of the subject zone depending on beat and screen.
2. The panel had no maximum height or scrolling. On 320x568 it was up to 105% of the screen, on landscape phones 107-119%, so buttons and the header were pushed off-screen and unreachable (root is `overflow-hidden`).
3. Beats 1-3: the 2D lantern overlay has a fixed 224-288px height; on short stages it collided with the header and the hold-progress bar.
4. Beats 4 and 6: the drag-hint pill sat at the top-centre of the scene.
5. Postcard modal: no scrolling, content centred with `items-center`, so on short screens the Close button was off-screen above the top edge (measured -109px at 320x568, -129px at 740x360).
6. `h-screen`/`88vh` sizing ignored the mobile browser bar; no safe-area handling; tiny tap targets (8px progress dots, 20px colour dots).

## The fix (one layout, applied to every beat)
- **Stage / story-panel split** in `App.tsx`: the canvas, header and lantern overlay now live in a "stage" region; the story panel is a separate region. Portrait: panel below the stage (max 52% of the height, 60% for the final beat). Landscape (width of 560px or more): panel beside the stage (18-28rem wide), full height. The canvas simply resizes to the stage (the existing ResizeObserver handles it), so the camera frames the subject in the visible area.
- **Panel structure:** progress dots pinned at top, title + note + paragraphs in a scrolling reading area, actions and previous/next pinned at the bottom (always reachable). Final beat: paragraphs scroll, the three-line ending and buttons are pinned.
- Narrative text is 14px (was 12px on phones). No font was reduced.
- Lantern overlay shrinks to fit the stage; hint pill moved to the stage's bottom edge, away from the subject.
- Safe areas: `viewport-fit=cover` and `env(safe-area-inset-*)` padding on header, panel and both modals. `dvh` units everywhere.
- Postcard modal and sketchbook scroll and keep their Close button on screen.
- Tap areas enlarged without changing the look (invisible padding on progress and colour dots; larger stepper and sound buttons on touch widths).
- Copy, story, beats, animations, 3D scenes, camera and lighting: untouched.

## Beat by beat (measured; share of the subject zone covered by text/panel, before -> after)
Phone 390x844 / phone 360x740 / laptop 1366x768
| Beat | Cause before | 390x844 | 360x740 | 1366x768 | After |
|---|---|---|---|---|---|
| 1 Doorstep (hold) | Panel over lower subject; 2D lantern + hold bar tight | 37% -> 0% | 45% -> 0% | 21% -> 0% | Lantern shrinks to fit stage; hold bar visible |
| 2 Flame choice | Tallest panel (4 flame cards + description) | 75% -> 0% | 58% -> 0% | 59% -> 0% | At 360x740 the panel scrolls slightly |
| 3 Wish | Wish card + button stacked | 61% -> 0% | 58% -> 0% | 59% -> 0% | No overlap |
| 4 Sleeping Street | Panel plus hint pill over the street | 56% -> 0% | 85% -> 0% | 57% -> 0% | Street fully visible; hint pill at the bottom edge |
| 5 First postcard | Panel covers arch | 43% -> 0% | 82% -> 0% | 50% -> 0% | No overlap |
| 6 Water steps | Panel + hint pill | 42% -> 0% | 61% -> 0% | 41% -> 0% | No overlap |
| 7 Stone gate | Long action label wraps | 66% -> 0% | 88% -> 0% | 50% -> 0% | No overlap |
| 8 Timber gallery | Hold/tap button wraps | 53% -> 0% | 88% -> 0% | 41% -> 0% | No overlap |
| 9 Her street | Tallest panel (ending + buttons) | 75% -> 0% | 100% -> 0% | 66% -> 0% | Ending always visible (pinned) |
Smallest phone (320x568): beat 9 still overlaps 19% of the subject zone because the two-row header and the taller final panel leave a 227px stage; beats 2, 4, 9 scroll inside the panel. Landscape phones (740x360, 844x390): stage is 61-64% of the screen, panel scrolls for 2-3 beats.
Stage share of screen (smallest across beats): 40-48% on phones in portrait, 61-64% on landscape phones, 62% tablet portrait, 64-77% laptops/desktops.

## Trade-offs and open decisions
- On portrait phones the scene is no longer full-bleed behind the text; it occupies 40-58% of the height but is completely unobstructed. If you prefer a taller scene, the panel could be made collapsible (a handle to hide the reading text); I did not add new interactions.
- Beats 1-3 still show the 2D SVG lantern over the 3D doorstep, which also contains a 3D lantern. Whether this reads as two lanterns can only be judged on the live 3D scene. Left as is.
- Readable-against-every-background: the panel is now opaque over a dark page background, so text contrast does not depend on the scene. Header controls still sit over the scene with a dark gradient; their contrast against the real scenes is unverified.
- The progress dots are still narrow (about 16px) tap targets; the previous/next buttons are the large targets.
