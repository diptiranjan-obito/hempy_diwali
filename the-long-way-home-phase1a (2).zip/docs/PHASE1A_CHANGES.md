# Phase 1A: changes, honesty ledger

## Verification status (what was and was not actually done)
| Item | Status |
|---|---|
| `npm ci` / `npm run build` | NOT RUN (no network/dependencies in my environment) |
| TypeScript type-check | NOT RUN |
| 3D scene mounting, rendering, screenshots | NOT RUN |
| GitHub Actions workflows | NOT RUN. YAML parses; the ZIP-unpack shell logic was tested locally on a toy ZIP |
| Syntax of every changed source file | Checked with esbuild: passes |
| `package-lock.json` vs `package.json` | Root dependency lists match exactly; every entry has a resolved URL and integrity hash; rollup 4.68.0 satisfies vite-plugin-singlefile's peer range; Node 22 satisfies the vite/plugin engines. NOT checked against the live npm registry |
| GitHub Action versions (checkout v4, setup-node v4, configure-pages v5, upload-pages-artifact v3, deploy-pages v4) | Chosen from memory of a known-good combination; newer majors may exist; not checked online |

## Changes kept (stability / delivery only)
- `MiniatureWorldCanvas.tsx`: scene effect no longer depends on the parent's callback (it used to rebuild the whole renderer on every App re-render); full GPU resource cleanup + `forceContextLoss`; canvas removed on unmount; ResizeObserver; pointercancel; `touch-action: none`; WebGL-failure message; reused Colour objects instead of per-frame allocation.
- `App.tsx`: `h-dvh` instead of `h-screen`; cancels the hold animation on unmount; developer controls and drawer now render only in `vite dev`.
- `index.html`: added `noindex, nofollow`. `vite.config.ts`: `base: './'`. `.gitignore`, workflows, docs added.
- `StageReviewDrawer.tsx` moved to `src/dev/`; `LANTERN_SPEC_CHECKLIST` moved to `src/dev/lanternSpecChecklist.ts` with a warning (one of its claims is demonstrably wrong: it states ring radii 0.62/0.48, the 3D rig uses 0.29/0.23). `src/vite-env.d.ts` added for `import.meta.env`.

## Changes REVERTED (they would have altered the look; now Phase 1B candidates to judge on the live site)
1. sRGB colour space on the procedural textures (`proceduralTextures.ts` is back to the original).
2. Applying each beat's `cameraPreset.fov` (the camera still stays at 38 degrees, as originally).
3. Turning off shadow casting for the lantern light and paper body (back to original; may self-shadow, and is expensive on phones).
4. Pixel-ratio cap lowered to 1.75 (back to 2).

## paperTintHex
Original value `'#dfna9e'` is not valid hex. The code never reads `paperTintHex` anywhere, so it had no runtime effect. The other three flames' tints are hand-picked blends (roughly 57% of the way from the flame colour to its core colour, with some variation), so no formula gives a single answer. `#dfea9e` is the one-character correction that fits that pattern best, but it is **an inference, not confirmed** by any design source. It is commented as such in the code. Please confirm or give the intended value.

## Not changed on purpose (needs your decision)
- Story data still contains developer-style labels shown to the recipient: `environmentLabel` ("Build 02 · The Sleeping Street") in the header and `subtitle` ("Beat 04 · Environmental Build: ...") in the story panel. Changing them edits story data, so I left them.
- The beat dots / previous-next buttons let a viewer jump between beats; left as designed.
- Google Fonts are loaded from Google's servers (`index.html`). That is a third-party request. Self-hosting needs the font files, which I cannot download here.
- Lantern: 3D rig remains the authoritative design; the SVG rig is unchanged.

## Remaining blockers
- First real build/deploy has not happened; any dependency or type error will only show then.
- Whether the dev-tool code is fully removed from the bundle is checked automatically by the workflow's guard step, not by me.


---
# Round 2 additions

## Recipient-visible wording changed (labels only; no story text, order or scene composition touched)
Header line and footer caption, previously dev labels, are now in-world:
| Beat | Header (was) | Header (now) | Caption (was) | Caption (now) |
|---|---|---|---|---|
| 1-3 | Build 01 · The Weathered Doorstep · Beat 0N of 09 | The Weathered Doorstep · N of 9 | Beat 0N · Environmental Build: Doorstep | At the doorstep |
| 4 | Build 02 · The Sleeping Street | The Sleeping Street | Beat 04 · Environmental Build: Sleeping Street (Scene 02) | Along the sleeping street |
| 5 | Build 02 · The Sleeping Street (Archway) | The Old Stone Arch | Beat 05 · First Postcard · Sleeping Street Archway | First postcard · The Old Stone Arch |
| 6 | Build 03 · The Water Steps | The Water Steps | Beat 06 · Second Postcard · Environmental Build: Water | Second postcard · The Water Steps |
| 7 | Build 04 · Market Through Gate | Through the Stone Gate | Beat 07 · Third Postcard · Environmental Build: Market Through Gate | Third postcard · Through the Stone Gate |
| 8 | Build 04 · Timber Gallery Above the Gate | The Timber Gallery | Beat 08 · Fourth Postcard · ... | Fourth postcard · The Timber Gallery |
| 9 | Finale · Her Street & The Lit Town | Her Street & the Lit Town | Beat 09 · Fifth Postcard · The Long Way Home | Fifth postcard · The Long Way Home |
Also: beat 4's note lost the prefix "Scene 02 study: "; progress dots' tooltips read "4. The Sleeping Street" instead of "Beat 04: ..."; unvisited cards in the sketchbook read "Along the way" instead of "Beat 0N". Every place name used already appears elsewhere in the story text. The three-line ending is untouched.
Left as is (not developer labels, but you may want to review): progress wording such as "(40% explored)" and "(60% ripples lit)", the "0/5" postcard counter, and "Instant Unfold (Reduced Motion)".

## Workflows
- ZIP-mode and source-mode workflows both start with a `check` job that decides, from the repository layout, whether they should build, so they cannot both publish. Both share concurrency group `pages` with cancel-in-progress off.
- ZIP mode: finds the shallowest package.json (flat ZIP, wrapped in a folder, or with `__MACOSX` junk), moves that folder to `project/`, and builds there.
- Both: a "Verify build output" step refuses to publish if index.html is missing, tiny (<150 KB), has no root element, contains a root-absolute `src`/`href`, or contains the developer-tool strings.

## `base: './'` on a project URL (reasoned, NOT verified by a build)
GitHub project pages live at `https://USER.github.io/REPO/`, so root-absolute paths like `/assets/x.js` would 404. The build uses `vite-plugin-singlefile`, which inlines the JS and CSS into `index.html`, leaving no local asset requests at all (no `public/` folder, no images, no `fetch` calls). If inlining behaves as designed, `base` is irrelevant. If it ever failed to inline something, `./assets/...` would still resolve correctly under `/REPO/` (Pages redirects `/REPO` to `/REPO/`). The "Verify build output" step fails the run if any root-absolute path appears, so a wrong base cannot be published silently. Remaining outside requests: Google Fonts (absolute https URLs, unaffected by base).

---
# Round 3: responsive layout (see LAYOUT_REPORT.md)
Files changed: `src/App.tsx` (stage/story-panel split, scroll structure, safe areas, tap areas), `src/components/LanternHeroRig.tsx` (lets the lantern shrink to the stage), `src/components/PostcardModal.tsx` (scrolls, safe areas), `src/index.css` (`side` landscape variant, quiet scrollbars), `index.html` (`viewport-fit=cover`). No story, copy, scene, camera or lighting changes. Verified only with a placeholder stage in headless Chromium; the real 3D scenes were not rendered.
